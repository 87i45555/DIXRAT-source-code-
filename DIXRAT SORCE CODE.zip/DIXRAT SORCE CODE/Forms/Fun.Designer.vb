﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Fun
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Fun))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.AbortRetryCancel = New System.Windows.Forms.RadioButton()
        Me.RetryCancel = New System.Windows.Forms.RadioButton()
        Me.YesNOCANCEL = New System.Windows.Forms.RadioButton()
        Me.OKCancel = New System.Windows.Forms.RadioButton()
        Me.YESNO = New System.Windows.Forms.RadioButton()
        Me.OK = New System.Windows.Forms.RadioButton()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Inf = New System.Windows.Forms.RadioButton()
        Me.Que = New System.Windows.Forms.RadioButton()
        Me.Ast = New System.Windows.Forms.RadioButton()
        Me.Err = New System.Windows.Forms.RadioButton()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Black
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(88, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(468, 49)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Speak"
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(303, 18)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 21)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Test"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(384, 18)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 21)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Send"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.Black
        Me.TextBox1.ForeColor = System.Drawing.Color.White
        Me.TextBox1.Location = New System.Drawing.Point(6, 19)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(291, 20)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "Your computer is speaking to you"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Black
        Me.GroupBox2.Controls.Add(Me.Button5)
        Me.GroupBox2.Controls.Add(Me.Button4)
        Me.GroupBox2.Controls.Add(Me.Button3)
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(79, 176)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Power"
        '
        'Button5
        '
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Image = CType(resources.GetObject("Button5.Image"), System.Drawing.Image)
        Me.Button5.Location = New System.Drawing.Point(15, 69)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(48, 45)
        Me.Button5.TabIndex = 5
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.Location = New System.Drawing.Point(15, 119)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(48, 45)
        Me.Button4.TabIndex = 4
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.Location = New System.Drawing.Point(15, 19)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(48, 45)
        Me.Button3.TabIndex = 3
        Me.Button3.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Black
        Me.GroupBox3.Controls.Add(Me.GroupBox6)
        Me.GroupBox3.Controls.Add(Me.GroupBox5)
        Me.GroupBox3.Controls.Add(Me.Button7)
        Me.GroupBox3.Controls.Add(Me.GroupBox4)
        Me.GroupBox3.Controls.Add(Me.Button6)
        Me.GroupBox3.ForeColor = System.Drawing.Color.White
        Me.GroupBox3.Location = New System.Drawing.Point(6, 185)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(553, 162)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.TextBox3)
        Me.GroupBox6.Controls.Add(Me.TextBox2)
        Me.GroupBox6.ForeColor = System.Drawing.Color.White
        Me.GroupBox6.Location = New System.Drawing.Point(6, 11)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(307, 146)
        Me.GroupBox6.TabIndex = 9
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Messagebox"
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.Black
        Me.TextBox3.ForeColor = System.Drawing.Color.White
        Me.TextBox3.Location = New System.Drawing.Point(6, 44)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(295, 96)
        Me.TextBox3.TabIndex = 4
        Me.TextBox3.Text = "Your computer is haunted."
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.Black
        Me.TextBox2.ForeColor = System.Drawing.Color.White
        Me.TextBox2.Location = New System.Drawing.Point(6, 19)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(295, 20)
        Me.TextBox2.TabIndex = 3
        Me.TextBox2.Text = "Hello"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.AbortRetryCancel)
        Me.GroupBox5.Controls.Add(Me.RetryCancel)
        Me.GroupBox5.Controls.Add(Me.YesNOCANCEL)
        Me.GroupBox5.Controls.Add(Me.OKCancel)
        Me.GroupBox5.Controls.Add(Me.YESNO)
        Me.GroupBox5.Controls.Add(Me.OK)
        Me.GroupBox5.ForeColor = System.Drawing.Color.White
        Me.GroupBox5.Location = New System.Drawing.Point(319, 11)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(172, 119)
        Me.GroupBox5.TabIndex = 8
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Buttons"
        '
        'AbortRetryCancel
        '
        Me.AbortRetryCancel.AutoSize = True
        Me.AbortRetryCancel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AbortRetryCancel.Location = New System.Drawing.Point(22, 87)
        Me.AbortRetryCancel.Name = "AbortRetryCancel"
        Me.AbortRetryCancel.Size = New System.Drawing.Size(128, 18)
        Me.AbortRetryCancel.TabIndex = 5
        Me.AbortRetryCancel.Text = "Abort|Retry|Cancel"
        Me.AbortRetryCancel.UseVisualStyleBackColor = True
        '
        'RetryCancel
        '
        Me.RetryCancel.AutoSize = True
        Me.RetryCancel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RetryCancel.Location = New System.Drawing.Point(71, 42)
        Me.RetryCancel.Name = "RetryCancel"
        Me.RetryCancel.Size = New System.Drawing.Size(94, 18)
        Me.RetryCancel.TabIndex = 4
        Me.RetryCancel.Text = "Retry|Cancel"
        Me.RetryCancel.UseVisualStyleBackColor = True
        '
        'YesNOCANCEL
        '
        Me.YesNOCANCEL.AutoSize = True
        Me.YesNOCANCEL.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.YesNOCANCEL.Location = New System.Drawing.Point(35, 64)
        Me.YesNOCANCEL.Name = "YesNOCANCEL"
        Me.YesNOCANCEL.Size = New System.Drawing.Size(102, 18)
        Me.YesNOCANCEL.TabIndex = 3
        Me.YesNOCANCEL.Text = "Yes|No|Cancel"
        Me.YesNOCANCEL.UseVisualStyleBackColor = True
        '
        'OKCancel
        '
        Me.OKCancel.AutoSize = True
        Me.OKCancel.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OKCancel.Location = New System.Drawing.Point(69, 20)
        Me.OKCancel.Name = "OKCancel"
        Me.OKCancel.Size = New System.Drawing.Size(80, 18)
        Me.OKCancel.TabIndex = 2
        Me.OKCancel.Text = "OK|Cancel"
        Me.OKCancel.UseVisualStyleBackColor = True
        '
        'YESNO
        '
        Me.YESNO.AutoSize = True
        Me.YESNO.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.YESNO.Location = New System.Drawing.Point(7, 42)
        Me.YESNO.Name = "YESNO"
        Me.YESNO.Size = New System.Drawing.Size(62, 18)
        Me.YESNO.TabIndex = 1
        Me.YESNO.Text = "Yes|No"
        Me.YESNO.UseVisualStyleBackColor = True
        '
        'OK
        '
        Me.OK.AutoSize = True
        Me.OK.Checked = True
        Me.OK.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OK.Location = New System.Drawing.Point(23, 20)
        Me.OK.Name = "OK"
        Me.OK.Size = New System.Drawing.Size(40, 18)
        Me.OK.TabIndex = 0
        Me.OK.TabStop = True
        Me.OK.Text = "OK"
        Me.OK.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.ForeColor = System.Drawing.Color.White
        Me.Button7.Location = New System.Drawing.Point(436, 135)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(111, 21)
        Me.Button7.TabIndex = 1
        Me.Button7.Text = "Send"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.PictureBox4)
        Me.GroupBox4.Controls.Add(Me.PictureBox3)
        Me.GroupBox4.Controls.Add(Me.PictureBox2)
        Me.GroupBox4.Controls.Add(Me.PictureBox1)
        Me.GroupBox4.Controls.Add(Me.Inf)
        Me.GroupBox4.Controls.Add(Me.Que)
        Me.GroupBox4.Controls.Add(Me.Ast)
        Me.GroupBox4.Controls.Add(Me.Err)
        Me.GroupBox4.ForeColor = System.Drawing.Color.White
        Me.GroupBox4.Location = New System.Drawing.Point(497, 11)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(50, 119)
        Me.GroupBox4.TabIndex = 4
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Icon"
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(27, 87)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox4.TabIndex = 7
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(27, 66)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox3.TabIndex = 6
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(27, 46)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 5
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(27, 25)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'Inf
        '
        Me.Inf.AutoSize = True
        Me.Inf.Checked = True
        Me.Inf.Location = New System.Drawing.Point(7, 25)
        Me.Inf.Name = "Inf"
        Me.Inf.Size = New System.Drawing.Size(14, 13)
        Me.Inf.TabIndex = 3
        Me.Inf.TabStop = True
        Me.Inf.UseVisualStyleBackColor = True
        '
        'Que
        '
        Me.Que.AutoSize = True
        Me.Que.Location = New System.Drawing.Point(7, 66)
        Me.Que.Name = "Que"
        Me.Que.Size = New System.Drawing.Size(14, 13)
        Me.Que.TabIndex = 2
        Me.Que.UseVisualStyleBackColor = True
        '
        'Ast
        '
        Me.Ast.AutoSize = True
        Me.Ast.Location = New System.Drawing.Point(7, 46)
        Me.Ast.Name = "Ast"
        Me.Ast.Size = New System.Drawing.Size(14, 13)
        Me.Ast.TabIndex = 1
        Me.Ast.UseVisualStyleBackColor = True
        '
        'Err
        '
        Me.Err.AutoSize = True
        Me.Err.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Err.Location = New System.Drawing.Point(7, 87)
        Me.Err.Name = "Err"
        Me.Err.Size = New System.Drawing.Size(14, 13)
        Me.Err.TabIndex = 0
        Me.Err.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.Location = New System.Drawing.Point(319, 135)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(111, 21)
        Me.Button6.TabIndex = 2
        Me.Button6.Text = "Test"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.BackColor = System.Drawing.Color.Black
        Me.GroupBox7.Controls.Add(Me.CheckBox1)
        Me.GroupBox7.Controls.Add(Me.Button20)
        Me.GroupBox7.Controls.Add(Me.Button19)
        Me.GroupBox7.Controls.Add(Me.Button18)
        Me.GroupBox7.Controls.Add(Me.Button17)
        Me.GroupBox7.Controls.Add(Me.Button16)
        Me.GroupBox7.Controls.Add(Me.Button12)
        Me.GroupBox7.Controls.Add(Me.Button13)
        Me.GroupBox7.Controls.Add(Me.Button14)
        Me.GroupBox7.Controls.Add(Me.Button15)
        Me.GroupBox7.Controls.Add(Me.Button10)
        Me.GroupBox7.Controls.Add(Me.Button11)
        Me.GroupBox7.Controls.Add(Me.Button9)
        Me.GroupBox7.Controls.Add(Me.Button8)
        Me.GroupBox7.ForeColor = System.Drawing.Color.White
        Me.GroupBox7.Location = New System.Drawing.Point(88, 61)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(222, 121)
        Me.GroupBox7.TabIndex = 3
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Cursed Piano"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(7, 100)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(90, 18)
        Me.CheckBox1.TabIndex = 13
        Me.CheckBox1.Text = "Piano Noise"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.Color.Black
        Me.Button20.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button20.Location = New System.Drawing.Point(155, 19)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(16, 45)
        Me.Button20.TabIndex = 12
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.Color.Black
        Me.Button19.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button19.Location = New System.Drawing.Point(129, 19)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(16, 45)
        Me.Button19.TabIndex = 11
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.Color.Black
        Me.Button18.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button18.Location = New System.Drawing.Point(103, 19)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(16, 45)
        Me.Button18.TabIndex = 10
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.Color.Black
        Me.Button17.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button17.Location = New System.Drawing.Point(51, 19)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(16, 45)
        Me.Button17.TabIndex = 9
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.Color.Black
        Me.Button16.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button16.Location = New System.Drawing.Point(25, 19)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(16, 45)
        Me.Button16.TabIndex = 8
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.Color.White
        Me.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button12.Location = New System.Drawing.Point(189, 19)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(26, 75)
        Me.Button12.TabIndex = 7
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.Color.White
        Me.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button13.Location = New System.Drawing.Point(163, 19)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(26, 75)
        Me.Button13.TabIndex = 6
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.White
        Me.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button14.Location = New System.Drawing.Point(137, 19)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(26, 75)
        Me.Button14.TabIndex = 5
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.Color.White
        Me.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button15.Location = New System.Drawing.Point(111, 19)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(26, 75)
        Me.Button15.TabIndex = 4
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.White
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button10.Location = New System.Drawing.Point(85, 19)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(26, 75)
        Me.Button10.TabIndex = 3
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.White
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button11.Location = New System.Drawing.Point(59, 19)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(26, 75)
        Me.Button11.TabIndex = 2
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.White
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button9.Location = New System.Drawing.Point(33, 19)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(26, 75)
        Me.Button9.TabIndex = 1
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.White
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button8.Location = New System.Drawing.Point(7, 19)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(26, 75)
        Me.Button8.TabIndex = 0
        Me.Button8.UseVisualStyleBackColor = False
        '
        'GroupBox8
        '
        Me.GroupBox8.BackColor = System.Drawing.Color.Black
        Me.GroupBox8.Controls.Add(Me.Button24)
        Me.GroupBox8.Controls.Add(Me.Button23)
        Me.GroupBox8.Controls.Add(Me.Button22)
        Me.GroupBox8.Controls.Add(Me.Button21)
        Me.GroupBox8.ForeColor = System.Drawing.Color.White
        Me.GroupBox8.Location = New System.Drawing.Point(316, 61)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(240, 121)
        Me.GroupBox8.TabIndex = 4
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Hide && Show"
        '
        'Button24
        '
        Me.Button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button24.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.ForeColor = System.Drawing.Color.White
        Me.Button24.Image = CType(resources.GetObject("Button24.Image"), System.Drawing.Image)
        Me.Button24.Location = New System.Drawing.Point(6, 68)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(111, 43)
        Me.Button24.TabIndex = 13
        Me.Button24.Text = "Hide Icons"
        Me.Button24.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button23.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.ForeColor = System.Drawing.Color.White
        Me.Button23.Image = CType(resources.GetObject("Button23.Image"), System.Drawing.Image)
        Me.Button23.Location = New System.Drawing.Point(123, 68)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(111, 43)
        Me.Button23.TabIndex = 12
        Me.Button23.Text = "Show Icons"
        Me.Button23.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button23.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button22.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.ForeColor = System.Drawing.Color.White
        Me.Button22.Image = CType(resources.GetObject("Button22.Image"), System.Drawing.Image)
        Me.Button22.Location = New System.Drawing.Point(6, 20)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(111, 43)
        Me.Button22.TabIndex = 11
        Me.Button22.Text = "Hide Taskbar"
        Me.Button22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button22.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button21.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.ForeColor = System.Drawing.Color.White
        Me.Button21.Image = CType(resources.GetObject("Button21.Image"), System.Drawing.Image)
        Me.Button21.Location = New System.Drawing.Point(123, 20)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(111, 43)
        Me.Button21.TabIndex = 10
        Me.Button21.Text = "Show Taskbar"
        Me.Button21.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button21.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button21.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(2, 2)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(570, 378)
        Me.TabControl1.TabIndex = 5
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Black
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox8)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.GroupBox7)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Location = New System.Drawing.Point(4, 23)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(562, 351)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Main Functions"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Black
        Me.TabPage2.Controls.Add(Me.GroupBox12)
        Me.TabPage2.Controls.Add(Me.GroupBox11)
        Me.TabPage2.Controls.Add(Me.GroupBox10)
        Me.TabPage2.Controls.Add(Me.GroupBox9)
        Me.TabPage2.Location = New System.Drawing.Point(4, 23)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(562, 351)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Other Fun Functions"
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.Button36)
        Me.GroupBox12.Controls.Add(Me.Button37)
        Me.GroupBox12.ForeColor = System.Drawing.Color.White
        Me.GroupBox12.Location = New System.Drawing.Point(393, 103)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(163, 88)
        Me.GroupBox12.TabIndex = 10
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Monitor Control"
        '
        'Button36
        '
        Me.Button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button36.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button36.Image = CType(resources.GetObject("Button36.Image"), System.Drawing.Image)
        Me.Button36.Location = New System.Drawing.Point(6, 52)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(151, 30)
        Me.Button36.TabIndex = 8
        Me.Button36.Text = "Turn Monitor OFF"
        Me.Button36.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button36.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Button37
        '
        Me.Button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button37.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button37.Image = CType(resources.GetObject("Button37.Image"), System.Drawing.Image)
        Me.Button37.Location = New System.Drawing.Point(6, 16)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(151, 30)
        Me.Button37.TabIndex = 9
        Me.Button37.Text = "Turn Monitor ON"
        Me.Button37.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button37.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button37.UseVisualStyleBackColor = True
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.Button35)
        Me.GroupBox11.Controls.Add(Me.Label3)
        Me.GroupBox11.Controls.Add(Me.Label2)
        Me.GroupBox11.Controls.Add(Me.CheckBox3)
        Me.GroupBox11.Controls.Add(Me.Label1)
        Me.GroupBox11.Controls.Add(Me.PictureBox5)
        Me.GroupBox11.ForeColor = System.Drawing.Color.White
        Me.GroupBox11.Location = New System.Drawing.Point(6, 193)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(550, 152)
        Me.GroupBox11.TabIndex = 2
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Master Boot Record | Requires Admin Privileges"
        '
        'Button35
        '
        Me.Button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button35.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button35.Image = CType(resources.GetObject("Button35.Image"), System.Drawing.Image)
        Me.Button35.Location = New System.Drawing.Point(277, 19)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(267, 127)
        Me.Button35.TabIndex = 10
        Me.Button35.Text = "Destroy MBR"
        Me.Button35.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button35.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(22, 132)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(252, 14)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Overwriting the MBR renders disk unusable."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(135, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 22)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Disabled"
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox3.Location = New System.Drawing.Point(25, 66)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(95, 26)
        Me.CheckBox3.TabIndex = 13
        Me.CheckBox3.Text = "Reboot"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(61, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(139, 22)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "MBR Options:"
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(6, 129)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(21, 21)
        Me.PictureBox5.TabIndex = 16
        Me.PictureBox5.TabStop = False
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.Button33)
        Me.GroupBox10.Controls.Add(Me.Button34)
        Me.GroupBox10.ForeColor = System.Drawing.Color.White
        Me.GroupBox10.Location = New System.Drawing.Point(393, 9)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(164, 88)
        Me.GroupBox10.TabIndex = 1
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "CD Control"
        '
        'Button33
        '
        Me.Button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button33.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button33.Image = CType(resources.GetObject("Button33.Image"), System.Drawing.Image)
        Me.Button33.Location = New System.Drawing.Point(6, 50)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(151, 30)
        Me.Button33.TabIndex = 8
        Me.Button33.Text = "Close CD Drive"
        Me.Button33.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button33.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button34.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button34.Image = CType(resources.GetObject("Button34.Image"), System.Drawing.Image)
        Me.Button34.Location = New System.Drawing.Point(6, 14)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(151, 30)
        Me.Button34.TabIndex = 9
        Me.Button34.Text = "Eject CD Drive"
        Me.Button34.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button34.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button34.UseVisualStyleBackColor = True
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Button41)
        Me.GroupBox9.Controls.Add(Me.Button40)
        Me.GroupBox9.Controls.Add(Me.Button39)
        Me.GroupBox9.Controls.Add(Me.Button38)
        Me.GroupBox9.Controls.Add(Me.Button32)
        Me.GroupBox9.Controls.Add(Me.Button31)
        Me.GroupBox9.Controls.Add(Me.Button30)
        Me.GroupBox9.Controls.Add(Me.Button29)
        Me.GroupBox9.Controls.Add(Me.Button28)
        Me.GroupBox9.Controls.Add(Me.Button27)
        Me.GroupBox9.Controls.Add(Me.Button26)
        Me.GroupBox9.Controls.Add(Me.Button25)
        Me.GroupBox9.ForeColor = System.Drawing.Color.White
        Me.GroupBox9.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(381, 185)
        Me.GroupBox9.TabIndex = 0
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "GDI+ Functions"
        '
        'Button41
        '
        Me.Button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button41.Image = CType(resources.GetObject("Button41.Image"), System.Drawing.Image)
        Me.Button41.Location = New System.Drawing.Point(254, 139)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(116, 33)
        Me.Button41.TabIndex = 11
        Me.Button41.Text = "System Icons"
        Me.Button41.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button41.UseVisualStyleBackColor = True
        '
        'Button40
        '
        Me.Button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button40.Image = CType(resources.GetObject("Button40.Image"), System.Drawing.Image)
        Me.Button40.Location = New System.Drawing.Point(254, 100)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(116, 33)
        Me.Button40.TabIndex = 10
        Me.Button40.Text = "Crazy Lines"
        Me.Button40.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button40.UseVisualStyleBackColor = True
        '
        'Button39
        '
        Me.Button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button39.Image = CType(resources.GetObject("Button39.Image"), System.Drawing.Image)
        Me.Button39.Location = New System.Drawing.Point(254, 61)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(116, 33)
        Me.Button39.TabIndex = 9
        Me.Button39.Text = "Draw a Face"
        Me.Button39.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button39.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button38.Image = CType(resources.GetObject("Button38.Image"), System.Drawing.Image)
        Me.Button38.Location = New System.Drawing.Point(254, 22)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(116, 33)
        Me.Button38.TabIndex = 8
        Me.Button38.Text = "Draw Rainbow"
        Me.Button38.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button38.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button32.Image = CType(resources.GetObject("Button32.Image"), System.Drawing.Image)
        Me.Button32.Location = New System.Drawing.Point(132, 139)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(116, 33)
        Me.Button32.TabIndex = 7
        Me.Button32.Text = "Screw Mouse"
        Me.Button32.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button32.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button31.Image = CType(resources.GetObject("Button31.Image"), System.Drawing.Image)
        Me.Button31.Location = New System.Drawing.Point(10, 139)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(116, 33)
        Me.Button31.TabIndex = 6
        Me.Button31.Text = "Zoom Out"
        Me.Button31.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button31.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button30.Image = CType(resources.GetObject("Button30.Image"), System.Drawing.Image)
        Me.Button30.Location = New System.Drawing.Point(132, 100)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(116, 33)
        Me.Button30.TabIndex = 5
        Me.Button30.Text = "Mirror Screen"
        Me.Button30.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button30.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button29.Image = CType(resources.GetObject("Button29.Image"), System.Drawing.Image)
        Me.Button29.Location = New System.Drawing.Point(132, 61)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(116, 33)
        Me.Button29.TabIndex = 4
        Me.Button29.Text = "Flip Screen"
        Me.Button29.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button29.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button28.Image = CType(resources.GetObject("Button28.Image"), System.Drawing.Image)
        Me.Button28.Location = New System.Drawing.Point(132, 22)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(116, 33)
        Me.Button28.TabIndex = 3
        Me.Button28.Text = "Invert Screen"
        Me.Button28.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button28.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button27.Image = CType(resources.GetObject("Button27.Image"), System.Drawing.Image)
        Me.Button27.Location = New System.Drawing.Point(10, 100)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(116, 33)
        Me.Button27.TabIndex = 2
        Me.Button27.Text = "Black Screen"
        Me.Button27.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button27.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button26.Image = CType(resources.GetObject("Button26.Image"), System.Drawing.Image)
        Me.Button26.Location = New System.Drawing.Point(10, 61)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(116, 33)
        Me.Button26.TabIndex = 1
        Me.Button26.Text = "White Screen"
        Me.Button26.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button26.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button25.Image = CType(resources.GetObject("Button25.Image"), System.Drawing.Image)
        Me.Button25.Location = New System.Drawing.Point(10, 22)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(116, 33)
        Me.Button25.TabIndex = 0
        Me.Button25.Text = "Random Hue"
        Me.Button25.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button25.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Fun
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(575, 383)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Fun"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fun"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Button7 As Button
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Inf As RadioButton
    Friend WithEvents Que As RadioButton
    Friend WithEvents Ast As RadioButton
    Friend WithEvents Err As RadioButton
    Friend WithEvents Button6 As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents AbortRetryCancel As RadioButton
    Friend WithEvents RetryCancel As RadioButton
    Friend WithEvents YesNOCANCEL As RadioButton
    Friend WithEvents OKCancel As RadioButton
    Friend WithEvents YESNO As RadioButton
    Friend WithEvents OK As RadioButton
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents Button20 As Button
    Friend WithEvents Button19 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents Button24 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Button22 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button35 As Button
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents Button34 As Button
    Friend WithEvents Button33 As Button
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents Button32 As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents Button28 As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents Button25 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents GroupBox12 As GroupBox
    Friend WithEvents Button36 As Button
    Friend WithEvents Button37 As Button
    Friend WithEvents Button39 As Button
    Friend WithEvents Button38 As Button
    Friend WithEvents Button41 As Button
    Friend WithEvents Button40 As Button
End Class
